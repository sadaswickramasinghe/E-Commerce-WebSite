<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:');
}

if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = $_POST['product_quantity'];

   $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($check_cart_numbers) > 0){
      $message[] = 'already added to cart!';
   }else{
      mysqli_query($conn, "INSERT INTO `cart`(user_id, name, price, quantity, image) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
      $message[] = 'product added to cart!';
   }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="test.css">

    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&display=swap" rel="stylesheet">
    
</head>
<body>
<?php include 'header.php'; ?>
    <section class="home">

        <div class="content">
           
        </div>
     
     </section>
     
     <section class="features" id="features">

    <h1 class="features-heading"> Our <span>Features</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="images/f2.png" alt="">
            <h3>fresh and organic</h3>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deserunt, earum!</p>
            <a href="#" class="btn">read more</a>
        </div>

        <div class="box">
            <img src="images/f3.png" alt="">
            <h3>free delivery</h3>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deserunt, earum!</p>
            <a href="#" class="btn">read more</a>
        </div>

        <div class="box">
            <img src="images/f1.webp" alt="">
            <h3>easy payments</h3>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deserunt, earum!</p>
            <a href="#" class="btn">read more</a>
        </div>

    </div>

</section>
<section class="banner" id="banner">
    <div class="banner-content">
        <div class="banner-text">
            <h1>Discover the Best Anime Collection</h1>
            <p>Explore our wide range of anime merchandise and accessories. Find your favorite characters and show off your love for anime with our exclusive collection.</p>
            <a href="#" class="btn">Shop Now</a>
        </div>
    </div>
</section>

     <section class="categories" id="categories">

<h1 class="categories-heading">Product <span>Categories</span></h1>

<div class="categories-box-container">

    <div class="categories-box">
        <img src="e.jpg" alt="Vegetables">
        <h3>Vegetables</h3>
        <p>Upto 45% off</p>
        <a href="#" class="btn">Shop Now</a>
    </div>

    <div class="categories-box">
        <img src="e.jpg" alt="Fresh Fruits">
        <h3>Fresh Fruits</h3>
        <p>Upto 45% off</p>
        <a href="#" class="btn">Shop Now</a>
    </div>

    <div class="categories-box">
        <img src="e.jpg" alt="Dairy Products">
        <h3>Dairy Products</h3>
        <p>Upto 45% off</p>
        <a href="#" class="btn">Shop Now</a>
    </div>

    <div class="categories-box">
        <img src="e.jpg" alt="Fresh Meat">
        <h3>Fresh Meat</h3>
        <p>Upto 45% off</p>
        <a href="#" class="btn">Shop Now</a>
    </div>

</div>

</section>





<?php include 'footer.php'; ?>

    <!-- JavaScript link -->
    <script type="text/javascript" src="script.js"></script>
</body>
</html>
