<?php
session_start();
include 'config.php';

// Check if user is logged in
$is_logged_in = isset($_SESSION['user_name']) || isset($_SESSION['admin_name']);

// Define the user ID if logged in
$user_id = $_SESSION['user_id'] ?? $_SESSION['admin_id'] ?? null;

// Get the cart item count
$cart_rows_number = 0;
if ($user_id) {
    $select_cart_number = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
    $cart_rows_number = mysqli_num_rows($select_cart_number);

    // Retrieve user email
    $select_user = mysqli_query($conn, "SELECT email FROM `users` WHERE id = '$user_id'") or die('query failed');
    if ($row = mysqli_fetch_assoc($select_user)) {
        $user_email = $row['email'];
    } else {
        $user_email = 'No email found';
    }
} else {
    $user_email = 'Not logged in';
}
?>

<!-- Top bar with social media and contact links -->
<div class="top-bar">
    <div class="social-links">
        <a href="https://facebook.com" target="_blank"><i class="ri-facebook-fill"></i></a>
        <a href="https://instagram.com" target="_blank"><i class="ri-instagram-fill"></i></a>
    </div>
    <div class="contact-links">
        <span><i class="ri-telegram-fill"></i> @username</span>
        <span><i class="ri-mail-fill"></i> example@example.com</span>
    </div>
</div>

<header>
    <a href="home.php" class="logo"><i class="ri-home-heart-fill">AniZone</i><span></span></a>
    <ul class="navbar">
        <li><a href="home.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="items.php">Menu</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div class="main">
        <?php if (!$is_logged_in): ?>
            <div class="dropdown">
                <button class="dropbtn"><i class="ri-folder-user-fill"></i></button>
                <div class="dropdown-content">
                    <a href="login.php">LogIn</a>
                    <a href="register.php">SignUp</a>
                </div>
            </div>
        <?php else: ?>
            <div class="user-icon" onclick="toggleUserInfo()">
                <p><?php echo $_SESSION['user_name'] ?? $_SESSION['admin_name']; ?></p>
                <div id="user-info-box" class="user-info-box">
                    <p class="user-info">Username: <?php echo $_SESSION['user_name'] ?? $_SESSION['admin_name']; ?></p>
                    <p class="user-info">Email: <?php echo htmlspecialchars($user_email); ?></p>
                    <a href="logout.php" class="logout-btn">Logout</a>
                </div>
            </div>
        <?php endif; ?>

        <a href="cart.php" class="cart-icon-link">
            <div class="cart-icon">
                <i class="ri-shopping-cart-2-line"></i><span id="cart-count">(<?php echo $cart_rows_number; ?>)</span>
            </div>
        </a>

        <div class="search-container">
            <a href="#" id="search-bar" class="search-bar"><i class="ri-search-fill"></i></a>
            <input type="text" id="search-input" class="search-input" placeholder="Search...">
        </div>

        <div class="bx bx-menu" id="menu-icon"></div>
    </div>
</header>

<script>
function toggleUserInfo() {
    var userInfoBox = document.getElementById('user-info-box');
    
    // Toggle visibility of the user-info-box
    if (userInfoBox.style.display === 'block') {
        userInfoBox.style.display = 'none';
    } else {
        userInfoBox.style.display = 'block';
    }
}

// Hide user info box if clicked outside
window.onclick = function(event) {
    var userIcon = document.querySelector('.user-icon');
    var userInfoBox = document.getElementById('user-info-box');
    
    if (!userIcon.contains(event.target) && !userInfoBox.contains(event.target)) {
        userInfoBox.style.display = 'none';
    }
}
</script>

</header>