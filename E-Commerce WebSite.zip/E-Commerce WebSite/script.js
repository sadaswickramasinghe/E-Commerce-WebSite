const menuIcon = document.getElementById('menu-icon');
const navbar = document.querySelector('.navbar');
const main = document.querySelector('.main');

menuIcon.addEventListener('click', () => {
    navbar.classList.toggle('open');
    main.classList.toggle('open');
});
