<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<footer>
    <div class="footer-container">
        <div class="footer-section">
            <h2>About Us</h2>
            <p>Discover our passion for anime and the unique collection we offer. Explore our site to find exclusive merchandise and stay updated with the latest trends in anime.</p>
        </div>

        <div class="footer-section">
            <h2>Quick Links</h2>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="items.php">Menu</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="privacy.php">Privacy Policy</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h2>Contact Us</h2>
            <p>Email: <a href="mailto:example@example.com">example@example.com</a></p>
            <p>Phone: +123 456 7890</p>
        </div>

        <div class="footer-section">
            <h2>Follow Us</h2>
            <div class="social-links">
                <a href="https://facebook.com" target="_blank"><i class="ri-facebook-fill"></i> Facebook</a>
                <a href="https://instagram.com" target="_blank"><i class="ri-instagram-fill"></i> Instagram</a>
                <a href="https://twitter.com" target="_blank"><i class="ri-twitter-fill"></i> Twitter</a>
                <a href="https://linkedin.com" target="_blank"><i class="ri-linkedin-fill"></i> LinkedIn</a>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; 2024 AniZone. All rights reserved.</p>
    </div>
</footer>
