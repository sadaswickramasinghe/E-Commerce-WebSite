document.addEventListener('DOMContentLoaded', () => {
    // JavaScript for sidebar toggle
    document.getElementById('sidebar-toggle').addEventListener('click', function() {
        const sidebar = document.getElementById('sidebar');
        const showBtn = document.getElementById('sidebar-show');

        if (sidebar.classList.contains('sidebar-hidden')) {
            sidebar.classList.remove('sidebar-hidden');
            showBtn.style.display = 'none'; // Hide show button when sidebar is visible
        } else {
            sidebar.classList.add('sidebar-hidden');
            showBtn.style.display = 'block'; // Show show button when sidebar is hidden
        }
    });

    // JavaScript for sidebar show button
    document.getElementById('sidebar-show').addEventListener('click', function() {
        const sidebar = document.getElementById('sidebar');
        const showBtn = document.getElementById('sidebar-show');

        if (sidebar.classList.contains('sidebar-hidden')) {
            sidebar.classList.remove('sidebar-hidden');
            showBtn.style.display = 'none'; // Hide show button when sidebar is visible
        }
    });

    // JavaScript for user profile box
    document.getElementById('user-icon').addEventListener('click', function() {
        const userProfile = document.getElementById('user-profile');
        
        if (userProfile.classList.contains('show')) {
            userProfile.classList.remove('show'); // Hide the profile box
        } else {
            userProfile.classList.add('show'); // Show the profile box
        }
    });

    // Close the user profile box when clicking outside of it
    document.addEventListener('click', function(event) {
        const userProfile = document.getElementById('user-profile');
        const userIcon = document.getElementById('user-icon');

        if (!userProfile.contains(event.target) && !userIcon.contains(event.target)) {
            userProfile.classList.remove('show');
        }
    });
});
