<?php
include 'config.php';
session_start();

$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}

$query = isset($_GET['query']) ? $_GET['query'] : '';

$search_results = [];

if (!empty($query)) {
    $search_query = mysqli_real_escape_string($conn, $query);
    $result = mysqli_query($conn, "SELECT * FROM `products` WHERE name LIKE '%$search_query%'") or die('query failed');

    while ($row = mysqli_fetch_assoc($result)) {
        $search_results[] = $row;
    }
}

// Handle add to cart
if (isset($_POST['add_to_cart'])) {

    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    $product_quantity = $_POST['product_quantity'];

    $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

    if (mysqli_num_rows($check_cart_numbers) > 0) {
        $message[] = 'already added to cart!';
    } else {
        mysqli_query($conn, "INSERT INTO `cart`(user_id, name, price, quantity, image) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
        $message[] = 'product added to cart!';
    }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include 'header.php'; ?>
    <div class="heading">
        <h3>Search Results</h3>
        <p><a href="home.php">home</a> / search results</p>
    </div>
    
    <section class="products">
        <h1 class="title">Search Results for "<?php echo htmlspecialchars($query); ?>"</h1>
        <div class="box-container">
            <?php  
            if (count($search_results) > 0) {
                foreach ($search_results as $product) {
            ?>
            <form action="" method="post" class="box">
                <img class="image" src="uploaded_img/<?php echo $product['image']; ?>" alt="">
                <div class="name"><?php echo $product['name']; ?></div>
                <div class="price">$<?php echo $product['price']; ?>/-</div>
                <input type="number" min="1" name="product_quantity" value="1" class="qty">
                <input type="hidden" name="product_name" value="<?php echo $product['name']; ?>">
                <input type="hidden" name="product_price" value="<?php echo $product['price']; ?>">
                <input type="hidden" name="product_image" value="<?php echo $product['image']; ?>">
                <input type="submit" value="add to cart" name="add_to_cart" class="btn">
            </form>
            <?php
                }
            } else {
                echo '<p class="empty">No products found!</p>';
            }
            ?>
        </div>
    </section>

    <!-- JavaScript link -->
    <script type="text/javascript" src="script.js"></script>
</body>
</html>
