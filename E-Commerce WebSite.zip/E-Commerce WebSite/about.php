<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:');
}

if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = $_POST['product_quantity'];

   $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($check_cart_numbers) > 0){
      $message[] = 'already added to cart!';
   }else{
      mysqli_query($conn, "INSERT INTO `cart`(user_id, name, price, quantity, image) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
      $message[] = 'product added to cart!';
   }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include 'header.php'; ?>
   

    <div class="heading">
        <h3>about us</h3>
        <p> <a href="home.php">home</a> / about </p>
     </div>
     
     <section class="about">
     
        <div class="flex">
     
            <div class="about-section" id="about">
                <img src="apple.jpg" alt="About Us Image">
                <div class="about-content">
                    <h2>What Are We!</h2>
                    <p>"Your Ultimate Destination for Premium Anime Statue Collectibles"

At AniZone, we are passionate about bringing the world of anime to life through meticulously crafted statues. Whether you're a seasoned collector or just starting your anime journey, our extensive selection of high-quality figures offers something for every fan. We pride ourselves on providing exceptional customer service and a seamless shopping experience, ensuring that each piece you add to your collection is nothing short of perfect. Join us in celebrating the art and magic of anime – one statue at a time.

</p>
                </div>
            </div>
            <?php include 'footer.php'; ?>
    <!-- JavaScript link -->
    <script type="text/javascript" src="script.js"></script>
</body>
</html>
