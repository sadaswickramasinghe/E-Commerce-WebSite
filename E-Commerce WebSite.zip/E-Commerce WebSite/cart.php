<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:');
}

if(isset($_POST['update_cart'])){
   $cart_id = $_POST['cart_id'];
   $cart_quantity = $_POST['cart_quantity'];
   mysqli_query($conn, "UPDATE `cart` SET quantity = '$cart_quantity' WHERE id = '$cart_id'") or die('query failed');
   $message[] = 'cart quantity updated!';
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `cart` WHERE id = '$delete_id'") or die('query failed');
   header('location:cart.php');
}

if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
   header('location:cart.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&display=swap" rel="stylesheet">
</head>
<body>
<?php include 'header.php'; ?>
    <div class="heading">
        <h3>Our Shop</h3>
        <p> <a href="home.php">Home</a> / Shop </p>
    </div>
     
    <section class="shopping-cart">
    <h1 class="cart-title">Products <span>Added</span></h1>

    <div class="cart-items">
        <?php
        $grand_total = 0;
        $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
        if (mysqli_num_rows($select_cart) > 0) {
            while ($fetch_cart = mysqli_fetch_assoc($select_cart)) {
                $sub_total = ($fetch_cart['quantity'] * $fetch_cart['price']);
                $grand_total += $sub_total;
        ?>
        <div class="cart-item">
            <a href="cart.php?delete=<?php echo $fetch_cart['id']; ?>" class="remove-item" onclick="return confirm('Delete this from cart?');">x</a>
            <img src="uploaded_img/<?php echo $fetch_cart['image']; ?>" alt="" class="item-image">
            <div class="item-name"><?php echo $fetch_cart['name']; ?></div>
            <div class="item-price">$<?php echo $fetch_cart['price']; ?>/-</div>
            <form action="" method="post" class="quantity-form">
                <input type="hidden" name="cart_id" value="<?php echo $fetch_cart['id']; ?>" class="hidden-input">
                <input type="number" min="1" name="cart_quantity" value="<?php echo $fetch_cart['quantity']; ?>" class="quantity-input">
                <input type="submit" name="update_cart" value="Update" class="update-button">
            </form>
            <div class="item-subtotal">Sub Total: <span>$<?php echo $sub_total; ?>/-</span></div>
        </div>
        <?php
            }
        } else {
            echo '<p class="empty-cart">Your cart is empty</p>';
        }
        ?>
    </div>

    <div class="actions">
        <a href="cart.php?delete_all" class="clear-cart <?php echo ($grand_total > 0) ? '' : 'disabled'; ?>" onclick="return confirm('Delete all from cart?');">Clear Cart</a>
    </div>

    <div class="cart-summary">
        <p>Total: <span>$<?php echo $grand_total; ?>/-</span></p>
        <div class="summary-buttons">
            <a href="shop.php" class="continue-shopping">Continue Shopping</a>
            <a href="checkout.php" class="checkout <?php echo ($grand_total > 0) ? '' : 'disabled'; ?>">Checkout</a>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>
    <!-- JavaScript link -->
    <script type="text/javascript" src="script.js"></script>
</body>
</html>
