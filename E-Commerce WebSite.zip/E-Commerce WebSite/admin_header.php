<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>
<div id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <h2 class="admin-panel-name">Admin Panel <i class="ri-user-line" id="user-icon"></i></h2>
            <button id="sidebar-toggle" class="toggle-btn">☰</button> <!-- Button to hide/show sidebar -->
            <div id="user-profile" class="user-profile">
            <div class="profile-info">
   <div class="profile-details">
      <h3><?php echo $_SESSION['admin_name']; ?></h3>
      <p>Admin</p>
   </div>
</div>

<div class="account-box">
   <p>username : <span><?php echo $_SESSION['admin_name']; ?></span></p>
   <p>email : <span><?php echo $_SESSION['admin_email']; ?></span></p>
   <a href="logout.php" class="delete-btn">logout</a>
   <div>new <a href="login.php">login</a> | <a href="register.php">register</a></div>
</div>

                <button id="profile-close" class="profile-close-btn">×</button> <!-- Close button -->
            </div>
        </div>
        <ul class="sidebar-menu">
            <li><a href="admin.php">Home</a></li>
            <li><a href="admin_products.php">Products</a></li>
            <li><a href="admin_orders.php">Orders</a></li>
            <li><a href="admin-users.php">Users</a></li>
            <li><a href="admin_contact.php">Messages</a></li>
        </ul>
    </div>

    <!-- Sidebar Show Button -->
    <button id="sidebar-show" class="show-btn">→</button> <!-- Arrow to show sidebar -->

    
